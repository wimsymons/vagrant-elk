require "logstash/outputs/rabbitmq/march_hare"
